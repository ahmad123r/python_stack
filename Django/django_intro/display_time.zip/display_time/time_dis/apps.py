from django.apps import AppConfig


class TimeDisConfig(AppConfig):
    name = 'time_dis'
